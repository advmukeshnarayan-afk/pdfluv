/* ===========================================================
   PDFDesk — accounts, plans, usage, shared chrome
   -----------------------------------------------------------
   DEMO AUTHENTICATION. Accounts live in this browser's
   localStorage only. Passwords are salted and hashed with
   SHA-256 so they aren't stored in the clear, but anyone with
   access to the machine can read the store. This is a
   front-end demo, not a secure auth system. Wire it to a real
   backend before putting it in front of anyone.
   =========================================================== */
(function (global) {
"use strict";

/* ---------- storage with a memory fallback ---------- */
var mem = {};
var LS = (function () {
  try { var k="__t"; localStorage.setItem(k,"1"); localStorage.removeItem(k); return localStorage; }
  catch (e) {
    return { getItem:function(k){return k in mem?mem[k]:null;},
             setItem:function(k,v){mem[k]=String(v);},
             removeItem:function(k){delete mem[k];} };
  }
})();
function get(k, dflt){ try{ var v=LS.getItem(k); return v==null?dflt:JSON.parse(v); }catch(e){ return dflt; } }
function set(k, v){ try{ LS.setItem(k, JSON.stringify(v)); }catch(e){} }

var K = { users:"pdfdesk.users", session:"pdfdesk.session", usage:"pdfdesk.usage", docs:"pdfdesk.docs" };

/* ---------- plans ---------- */
var PLANS = {
  free:     { name:"Free",     saves:3,        ocrPages:5,   ai:5,        price:0,   colour:"" },
  pro:      { name:"Pro",      saves:Infinity, ocrPages:100, ai:Infinity, price:399, colour:"pro" },
  business: { name:"Business", saves:Infinity, ocrPages:500, ai:Infinity, price:999, colour:"business" }
};

/* ---------- hashing ---------- */
async function hash(pw, salt){
  var enc = new TextEncoder().encode(salt + "::" + pw);
  if (global.crypto && crypto.subtle) {
    var buf = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(buf)).map(function(b){return b.toString(16).padStart(2,"0");}).join("");
  }
  var h = 0; for (var i=0;i<enc.length;i++){ h = (h*31 + enc[i]) | 0; }
  return "weak" + h;
}
function salt(){ 
  var a = new Uint8Array(12);
  (global.crypto ? crypto.getRandomValues(a) : a.forEach(function(_,i){a[i]=Math.random()*255;}));
  return Array.from(a).map(function(b){return b.toString(16).padStart(2,"0");}).join("");
}

/* ---------- account API ---------- */
var Auth = {
  users: function(){ return get(K.users, {}); },
  current: function(){
    var e = get(K.session, null);
    if (!e) return null;
    var u = this.users()[e];
    return u ? Object.assign({ email:e }, u) : null;
  },
  plan: function(){
    var u = this.current();
    return PLANS[(u && u.plan) || "free"];
  },
  planKey: function(){ var u=this.current(); return (u && u.plan) || "free"; },

  signup: async function(name, email, pw){
    email = String(email||"").trim().toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error("That email address doesn't look right.");
    if (!name || name.trim().length < 2) throw new Error("Enter your name.");
    if (!pw || pw.length < 8) throw new Error("Use a password of at least 8 characters.");
    var us = this.users();
    if (us[email]) throw new Error("An account already exists for that email. Try logging in.");
    var s = salt();
    us[email] = { name:name.trim(), salt:s, hash:await hash(pw, s), plan:"free", created:Date.now() };
    set(K.users, us); set(K.session, email);
    return this.current();
  },
  login: async function(email, pw){
    email = String(email||"").trim().toLowerCase();
    var u = this.users()[email];
    if (!u) throw new Error("No account found for that email.");
    if (await hash(pw, u.salt) !== u.hash) throw new Error("That password isn't right.");
    set(K.session, email);
    return this.current();
  },
  logout: function(){ set(K.session, null); },

  setPlan: function(key){
    var u = this.current(); if (!u) return false;
    var us = this.users(); us[u.email].plan = key; set(K.users, us); return true;
  },
  deleteAccount: function(){
    var u = this.current(); if (!u) return;
    var us = this.users(); delete us[u.email]; set(K.users, us); set(K.session, null);
  },

  /* ---- daily usage counters ---- */
  today: function(){ return new Date().toISOString().slice(0,10); },
  usageKey: function(){ var u=this.current(); return (u?u.email:"guest") + "|" + this.today(); },
  used: function(what){
    var all = get(K.usage, {});
    return (all[this.usageKey()] || {})[what] || 0;
  },
  allowance: function(what){
    var p = this.plan();
    if (what === "save") return p.saves;
    if (what === "ai")   return p.ai;
    return Infinity;
  },
  canUse: function(what){ return this.used(what) < this.allowance(what); },
  bump: function(what, n){
    var all = get(K.usage, {}), k = this.usageKey();
    all[k] = all[k] || {};
    all[k][what] = (all[k][what] || 0) + (n || 1);
    /* trim anything older than today so the store doesn't grow forever */
    var t = this.today();
    Object.keys(all).forEach(function(key){ if (key.split("|")[1] < t) delete all[key]; });
    set(K.usage, all);
  },

  /* ---- per-document notes: bookmarks and recent files ---- */
  docKey: function(name, size){ return (name||"doc") + "|" + (size||0); },
  loadDoc: function(key){ return get(K.docs, {})[key] || null; },
  saveDoc: function(key, data){
    var d = get(K.docs, {});
    d[key] = Object.assign({}, d[key], data, { touched: Date.now() });
    var keys = Object.keys(d).sort(function(a,b){ return d[b].touched - d[a].touched; });
    if (keys.length > 25) keys.slice(25).forEach(function(k){ delete d[k]; });
    set(K.docs, d);
  },
  recentDocs: function(){
    var d = get(K.docs, {});
    return Object.keys(d).map(function(k){ return Object.assign({ key:k }, d[k]); })
            .sort(function(a,b){ return b.touched - a.touched; });
  }
};

/* ---------- toast ---------- */
function toast(msg, kind){
  var t = document.getElementById("toast");
  if (!t){ t = document.createElement("div"); t.id="toast"; document.body.appendChild(t); }
  t.textContent = msg;
  t.className = "toast on" + (kind ? " " + kind : "");
  clearTimeout(t._t);
  t._t = setTimeout(function(){ t.className = "toast"; }, 3800);
}

/* ---------- auth modal ---------- */
var MODAL_HTML =
'<div class="modal" id="authModal" role="dialog" aria-modal="true" aria-labelledby="authTitle">' +
  '<div class="sheet">' +
    '<button class="x" id="authClose" aria-label="Close">&times;</button>' +
    '<h2 id="authTitle">Log in</h2>' +
    '<p class="sub" id="authSub">Welcome back. Your files stay on your device either way.</p>' +
    '<div class="err" id="authErr"></div>' +
    '<div class="field" id="nameField" hidden>' +
      '<label for="auName">Name</label><input id="auName" type="text" autocomplete="name" placeholder="Your name">' +
    '</div>' +
    '<div class="field"><label for="auEmail">Email</label>' +
      '<input id="auEmail" type="email" autocomplete="email" placeholder="you@example.com"></div>' +
    '<div class="field"><label for="auPw">Password</label>' +
      '<input id="auPw" type="password" autocomplete="current-password" placeholder="At least 8 characters"></div>' +
    '<button class="btn btn-primary btn-lg" id="auGo" style="width:100%">Log in</button>' +
    '<p class="swap" id="authSwap">New here? <button type="button">Create an account</button></p>' +
    '<p class="notice">Demo accounts are stored in this browser only — nothing is sent anywhere. ' +
      'Clearing your browser data removes them.</p>' +
  '</div>' +
'</div>';

var mode = "login";
function openAuth(which){
  mode = which || "login";
  var m = document.getElementById("authModal");
  m.classList.add("on");
  document.getElementById("authTitle").textContent = mode === "signup" ? "Create your account" : "Log in";
  document.getElementById("authSub").textContent = mode === "signup"
    ? "Free forever for everyday tasks. No card needed."
    : "Welcome back. Your files stay on your device either way.";
  document.getElementById("nameField").hidden = mode !== "signup";
  document.getElementById("auGo").textContent = mode === "signup" ? "Create account" : "Log in";
  document.getElementById("authSwap").innerHTML = mode === "signup"
    ? 'Already have an account? <button type="button">Log in</button>'
    : 'New here? <button type="button">Create an account</button>';
  document.getElementById("authSwap").querySelector("button").onclick = function(){ openAuth(mode==="signup"?"login":"signup"); };
  document.getElementById("auPw").setAttribute("autocomplete", mode==="signup"?"new-password":"current-password");
  document.getElementById("authErr").className = "err";
  setTimeout(function(){ document.getElementById(mode==="signup"?"auName":"auEmail").focus(); }, 40);
}
function closeAuth(){ document.getElementById("authModal").classList.remove("on"); }

async function submitAuth(){
  var err = document.getElementById("authErr");
  var go  = document.getElementById("auGo");
  err.className = "err"; go.disabled = true;
  try {
    if (mode === "signup") {
      await Auth.signup(document.getElementById("auName").value,
                        document.getElementById("auEmail").value,
                        document.getElementById("auPw").value);
      toast("Account created. You're signed in.", "good");
    } else {
      await Auth.login(document.getElementById("auEmail").value,
                       document.getElementById("auPw").value);
      toast("Signed in.", "good");
    }
    closeAuth(); paintHeader();
    document.dispatchEvent(new CustomEvent("pdfdesk:auth"));
    if (global.__afterAuth) { var f = global.__afterAuth; global.__afterAuth = null; f(); }
  } catch (e) {
    err.textContent = e.message; err.className = "err on";
  }
  go.disabled = false;
}

/* ---------- header ---------- */
function paintHeader(){
  var box = document.querySelector(".nav .acct");
  if (!box) return;
  var u = Auth.current();
  if (!u) {
    box.innerHTML =
      '<button class="btn btn-ghost" data-auth="login">Log in</button>' +
      '<button class="btn btn-primary" data-auth="signup">Sign up free</button>' +
      '<button class="burger" aria-label="Menu" aria-expanded="false">&#9776;</button>';
  } else {
    var p = Auth.plan(), initials = u.name.trim().split(/\s+/).map(function(w){return w[0];}).slice(0,2).join("").toUpperCase();
    box.innerHTML =
      '<span class="plan-chip ' + p.colour + '">' + p.name + '</span>' +
      '<button class="avatar" id="avatarBtn" aria-haspopup="true" aria-expanded="false" title="' + u.name + '">' + initials + '</button>' +
      '<div class="menu" id="acctMenu">' +
        '<div class="who"><b>' + esc(u.name) + '</b><span>' + esc(u.email) + '</span></div>' +
        '<a href="account.html">Your account</a>' +
        '<a href="editor.html">Open the editor</a>' +
        '<a href="pricing.html">Plans and billing</a>' +
        '<button class="danger" id="logoutBtn">Log out</button>' +
      '</div>' +
      '<button class="burger" aria-label="Menu" aria-expanded="false">&#9776;</button>';
    var av = document.getElementById("avatarBtn"), menu = document.getElementById("acctMenu");
    av.onclick = function(e){
      e.stopPropagation();
      var on = menu.classList.toggle("on");
      av.setAttribute("aria-expanded", on);
    };
    document.getElementById("logoutBtn").onclick = function(){
      Auth.logout(); paintHeader(); toast("Signed out.");
      document.dispatchEvent(new CustomEvent("pdfdesk:auth"));
    };
  }
  var b = box.querySelector(".burger"), links = document.querySelector(".nav .links");
  if (b && links) b.onclick = function(){
    var on = links.classList.toggle("open");
    b.setAttribute("aria-expanded", on);
  };
}
function esc(s){ return String(s).replace(/[&<>"]/g, function(c){
  return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]; }); }

/* ---------- boot ---------- */
function boot(){
  if (!document.getElementById("authModal")) {
    var d = document.createElement("div");
    d.innerHTML = MODAL_HTML;
    document.body.appendChild(d.firstChild);
    document.getElementById("authClose").onclick = closeAuth;
    document.getElementById("auGo").onclick = submitAuth;
    document.getElementById("authModal").addEventListener("click", function(e){
      if (e.target.id === "authModal") closeAuth();
    });
    ["auName","auEmail","auPw"].forEach(function(id){
      document.getElementById(id).addEventListener("keydown", function(e){
        if (e.key === "Enter") submitAuth();
      });
    });
  }
  document.addEventListener("click", function(e){
    var t = e.target.closest("[data-auth]");
    if (t) { openAuth(t.getAttribute("data-auth")); return; }
    var m = document.getElementById("acctMenu");
    if (m && !e.target.closest("#acctMenu") && !e.target.closest("#avatarBtn")) m.classList.remove("on");
  });
  document.addEventListener("keydown", function(e){ if (e.key === "Escape") closeAuth(); });
  addEventListener("scroll", function(){
    var h = document.querySelector("header.site");
    if (h) h.classList.toggle("stuck", scrollY > 8);
  });
  paintHeader();
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
else boot();

/* ---------- exports ---------- */
global.PDFDesk = {
  Auth: Auth, PLANS: PLANS, toast: toast, esc: esc,
  openAuth: openAuth, closeAuth: closeAuth, paintHeader: paintHeader,
  requireLogin: function(reason, then){
    if (Auth.current()) { then(); return true; }
    global.__afterAuth = then;
    toast(reason || "Log in to use this.", "");
    openAuth("login");
    return false;
  }
};
})(window);
