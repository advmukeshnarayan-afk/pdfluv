# PDFDesk

A complete browser-based PDF suite — editor, signatures, OCR, bookmarks,
page tools, an AI assistant, accounts and subscription plans.

Static files. No build step, no server, no install.

    index.html    home — tool grid, search, filters
    pricing.html  plans, comparison table, FAQ
    account.html  profile, plan, daily usage, recent documents
    editor.html   the workspace where all the real work happens
    style.css     shared shell — nav, buttons, cards, modals
    app.js        accounts, plans, usage counters, auth modal

## Running it

Keep all six files in one folder and open `index.html`. That's it.

To serve it properly:

    python3 -m http.server 8000
    # http://localhost:8000

To deploy: drag the folder onto Netlify Drop, or push to GitHub and
enable Pages. It's fully static, so any host works.

The first load needs a network connection to fetch pdf.js, pdf-lib and
the fonts from CDN. After that the editor works offline, except OCR
(downloads a language model on first use) and the AI panel.

---

## What actually works

Everything listed below is implemented and functional — not mocked.

**Viewing** — continuous scroll, lazy page rendering, thumbnails,
zoom steps, fit width, fit page, jump to page, full-text search across
the document with snippets and page jumps.

**Annotating** — highlight, freehand pen, text, box, and redact (an
opaque black rectangle). Six colours, adjustable thickness and font
size. Select tool picks up any annotation and drags it; the colour and
size controls retarget whatever is selected. Undo, delete, clear all.

**Signatures** — draw one with mouse, trackpad or finger, or type your
name and pick from three styles. Adjustable width. Click anywhere on a
page to place it. Drawn signatures are stored as normalised vector
paths so they scale cleanly.

**Page tools** — rotate left/right, delete a page, extract a page range
into a new PDF, merge another PDF onto the end, add page numbers from
any starting page, stamp a diagonal watermark, export a page as PNG at
3× resolution, and build a PDF from a set of JPG or PNG images.

**OCR** — real text recognition via Tesseract, running on your machine.
Read one page or the whole document, in English, Hindi, both together,
French, Spanish or German. Copy the text, download it as `.txt`, or
tick "Add invisible text layer on save" to write the recognised words
back into the PDF at their original positions, making a scan
searchable.

**Bookmarks** — reads the document's existing outline on open, lets you
add your own, jumps to any of them, and writes the whole set into the
saved PDF as a real outline that other readers will show.

**AI assistant** — extracts the document's text, sends it with your
question, answers with page references. See "The AI panel" below.

**Saving** — all markup is written into a real PDF with pdf-lib.
Highlights use multiply blend, pen strokes save as vectors, text as
embedded Helvetica. The output opens identically in any reader.

**Accounts and plans** — signup, login, logout, delete account. Free,
Pro and Business plans with real enforced daily limits on saves, OCR
pages and AI questions. Usage meters on the account page, counters
reset at midnight.

Keyboard: Ctrl+S save, Ctrl+Z undo, Ctrl+O open, Ctrl+F search,
Delete removes selection, Escape resets, V/H/P/T switch tools.

---

## Three things to know before you deploy this

**1. The authentication is a demo, not security.**
Accounts live in `localStorage` in one browser. Passwords are salted
and SHA-256 hashed so they aren't stored in the clear, but anyone with
access to the machine can read the store, and there is no server
verifying anything. Signing up on your laptop does not log you in on
your phone. Before this goes in front of real users it needs a real
backend — the whole surface is in `app.js` behind the `Auth` object,
so swapping the six methods (`signup`, `login`, `logout`, `setPlan`,
`used`, `bump`) for API calls is the entire job.

**2. There is no payment processor.**
Choosing a plan on the pricing page flips your demo account over
immediately so you can watch the limits change. Nothing is charged.
Wire it to Razorpay, Stripe or similar before taking money.

**3. The AI panel needs your own API key.**
There is no key shipped in these files, and there shouldn't be — a key
in a static site is a key anyone can read and spend. Click **Key** in
the AI panel and paste an Anthropic API key; it's held in
`sessionStorage` for that tab only and never written to disk. Calls go
straight from the browser to `api.anthropic.com` using the
`anthropic-dangerous-direct-browser-access` header.

Without a key the panel still works in a reduced local mode: word and
page counts, phrase lookups across the document, and a nudge to run OCR
if the file turns out to be a scan with no text layer.

For production, don't do this at all — put a small server endpoint
between the browser and the model, keep the key there, and have the
browser call your endpoint.

---

## Other limits worth knowing

- **Non-Latin text works, with one choice to make.** See below.
- **Existing text in the PDF can't be edited.** Annotations layer on
  top, which is what most PDF editors do anyway.
- **Redaction is visual, not forensic.** The black box covers the text;
  the text is still in the file underneath. True redaction requires
  removing the content stream operators.
- **No compression or Office conversion.** Those genuinely need a
  server — Ghostscript, LibreOffice or similar.
- **Encrypted PDFs** open read-only where pdf.js allows it, but saving
  will usually fail.

---

## Writing non-Latin text (Devanagari and others)

The **Text** dropdown on the Comment tab controls how text annotations
are written into the saved PDF. There are two routes because neither
is right for every case.

**Selectable text** embeds a real Unicode font (Mukta, fetched on
demand) using `@pdf-lib/fontkit`. The text stays selectable, copyable
and searchable in the saved file, and the file stays small.

The catch: pdf-lib drives fontkit's shaper, and that combination gets
most Devanagari right but not all of it. Tested on real text, `धारा 138
एन.आई. एक्ट` and `मुकेश नारायण` come out correct, including the क्ट
conjunct. Two things break — a pre-base matra lands on the wrong
consonant (`अधिवक्ता` renders as `अि धवक्ता`), and ra-conjuncts don't
form (`श्री` renders as `श ी`). If your text avoids those, this is the
better route.

Also note pdf-lib's font subsetter drops glyphs from complex fonts —
it mangles even plain English — so the font is embedded whole. That
adds roughly 200 KB to the saved file.

**Exact image** draws the text on a canvas first, where your browser's
own text engine does the shaping, and stamps the result into the PDF as
a PNG at 5× resolution. This always looks exactly as you typed it,
including every matra and conjunct. The cost is that the text is no
longer selectable, and each annotation adds a few KB.

**Auto** — the default — uses Helvetica for Latin-only text and the
image route for anything else, on the reasoning that a stamped note
needs to look right more than it needs to be selectable.

**Load font** lets you supply your own `.ttf` or `.otf`, for Tamil,
Bengali, Gurmukhi, Urdu or anything else Mukta doesn't cover. It's held
in memory for the session only.

Watermarks follow the same rules automatically: Latin text uses
Helvetica Bold, anything else embeds the Unicode font.

Screen display is separate from all of this — the page overlay and the
text input both use Mukta via Google Fonts, so what you type always
looks correct while you're working, whichever save route you pick.

## How the coordinate system works

Annotations are stored in PDF point coordinates on an SVG overlay whose
`viewBox` matches the unscaled page, so zooming never touches stored
data. `toPdfXY()` in `editor.html` converts SVG space (y-down, origin
top-left) to PDF space (y-up, origin bottom-left) and handles pages
carrying a `/Rotate` of 90, 180 or 270. Because 90° rotations preserve
axis alignment, rectangles are converted by transforming all four
corners and taking the bounding box.

Page operations that rewrite the document — rotate, delete, merge,
watermark, page numbers — first flatten current markup into the file,
then apply the change, then reload the viewer from the new bytes. You
get a confirmation prompt first, because flattening is permanent.

## Libraries

  - pdf.js 3.11.174 (Apache-2.0) — rendering, text extraction, outlines
  - pdf-lib 1.17.1 (MIT) — writing annotations, page ops, outlines
  - tesseract.js 5.0.4 (Apache-2.0) — OCR, loaded lazily on first use
  - @pdf-lib/fontkit 1.1.1 (MIT) — Unicode font embedding, lazy
  - Mukta (OFL) — Devanagari + Latin, fetched on demand from jsDelivr

To self-host them, download each plus `pdf.worker.min.js` into a
`vendor/` folder and repoint the `<script>` tags.

## Licence

The site code is yours. Keep the upstream notices if you redistribute
the libraries.
